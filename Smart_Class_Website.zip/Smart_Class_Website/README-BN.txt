SMART CLASS WEBSITE — Class 9–10
বিষয়: পদার্থবিজ্ঞান ও রসায়ন
পরিচালনায়: Kawsar Hamid

চালানোর নিয়ম:
1. ZIP ফাইলটি Extract করুন।
2. index.html ফাইলটি Chrome/যেকোনো ব্রাউজারে খুলুন।
3. ওয়েবসাইট সম্পাদনা করতে index.html, style.css ও script.js ফাইল পরিবর্তন করুন।

লাইভ করার সহজ উপায়:
- GitHub-এ একটি repository তৈরি করে এই ফাইলগুলো upload করুন।
- Repository Settings > Pages > Deploy from a branch নির্বাচন করুন।
- Branch হিসেবে main এবং folder হিসেবে /(root) নির্বাচন করে Save দিন।
- কিছুক্ষণ পর GitHub Pages-এর দেওয়া ঠিকানায় সাইট দেখা যাবে।

গুরুত্বপূর্ণ:
- এটি একটি প্রাথমিক static website starter।
- অধ্যায়ের নাম ও নমুনা MCQ দেওয়া আছে; পূর্ণ নোট/প্রশ্ন পরে যোগ করতে হবে।
- এই ZIP-এ Supabase সংযুক্ত করা নেই। Supabase URL ও anon key না থাকায় নিরাপদভাবে সংযোগের তথ্য বসানো হয়নি।
