const data = {
 physics: {title:"পদার্থবিজ্ঞান — অধ্যায়সমূহ", chapters:["ভৌত রাশি ও পরিমাপ","গতি","বল","কাজ, ক্ষমতা ও শক্তি","পদার্থের অবস্থা ও চাপ","বস্তুর ওপর তাপের প্রভাব","তরঙ্গ ও শব্দ","আলোর প্রতিফলন","আলোর প্রতিসরণ","স্থির বিদ্যুৎ"]},
 chemistry: {title:"রসায়ন — অধ্যায়সমূহ", chapters:["রসায়নের ধারণা","পদার্থের অবস্থা","পদার্থের গঠন","পর্যায় সারণি","রাসায়নিক বন্ধন","মোল ও রাসায়নিক গণনা","রাসায়নিক বিক্রিয়া","রসায়ন ও শক্তি","এসিড-ক্ষারক সমতা","খনিজ সম্পদ: ধাতু-অধাতু"]}
};
function showSubject(subject){
 const area=document.getElementById('chapter-area'); const item=data[subject];
 document.getElementById('chapter-title').textContent=item.title;
 document.getElementById('chapters').innerHTML=item.chapters.map((c,i)=>`<div class="chapter"><b>অধ্যায় ${i+1}</b><br>${c}<p><small>পাঠ ও নোট শিগগির যুক্ত হবে</small></p></div>`).join('');
 area.classList.remove('hidden'); area.scrollIntoView({behavior:'smooth'});
}
const questions=[
 {q:"দ্রুতির SI একক কোনটি?",opts:["মিটার","মিটার/সেকেন্ড","সেকেন্ড","কিলোগ্রাম"],a:1,why:"দ্রুতি = দূরত্ব ÷ সময়; SI একক m/s।"},
 {q:"বিশুদ্ধ পানির pH প্রায় কত?",opts:["2","5","7","12"],a:2,why:"২৫°C তাপমাত্রায় বিশুদ্ধ পানির pH প্রায় 7।"},
 {q:"বল-এর SI একক কী?",opts:["জুল","নিউটন","ওয়াট","প্যাসকেল"],a:1,why:"বলের SI একক নিউটন (N)।"}
];let qi=0,answered=false;
function startQuiz(){qi=0;document.getElementById('quiz').classList.remove('hidden');renderQuestion();document.getElementById('quiz').scrollIntoView({behavior:'smooth'});}
function renderQuestion(){answered=false;const q=questions[qi];document.getElementById('question').textContent=`প্রশ্ন ${qi+1}: ${q.q}`;document.getElementById('feedback').textContent="";document.getElementById('options').innerHTML=q.opts.map((o,i)=>`<button class="option" onclick="answer(${i})">${"কখগঘ"[i]}. ${o}</button>`).join('');}
function answer(i){if(answered)return;answered=true;const q=questions[qi];document.getElementById('feedback').textContent=(i===q.a?"সঠিক উত্তর! ":"সঠিক উত্তর: "+q.opts[q.a]+". ")+q.why;}
function nextQuestion(){if(!answered){document.getElementById('feedback').textContent="আগে একটি উত্তর নির্বাচন করুন।";return;}qi=(qi+1)%questions.length;renderQuestion();}
document.getElementById('year').textContent=new Date().getFullYear();
